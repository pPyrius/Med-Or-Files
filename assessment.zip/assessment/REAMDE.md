# Ideas

```bash 
ecb enc image showing password to decrypt itself
containing password to a zip file in steg
executing binary it says that it's not signed since it doesn't find any .sig sector
using private key to create digital signature to append to .sig. 
Once done it prints flag
```
